--------------------
Extra: Rocket Reviews
--------------------
Version: 1.0
Since: October 17th, 2021
Author: Wayne Roddy <wayne@rocketcitydigital.com>

A simple "Reviews" extra for MODX 2.8.+
