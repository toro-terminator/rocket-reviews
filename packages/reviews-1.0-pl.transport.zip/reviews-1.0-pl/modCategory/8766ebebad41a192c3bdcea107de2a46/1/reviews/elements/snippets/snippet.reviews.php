<?php
/**
 * @package reviews
 */
$rev = $modx->getService('reviews','Reviews',$modx->getOption('reviews.core_path',null,$modx->getOption('core_path').'components/reviews/').'model/reviews/',$scriptProperties);
if (!($rev instanceof Reviews)) return '';

/* setup default properties */
$tpl = $modx->getOption('tpl',$scriptProperties,'rowTpl');
$sort = $modx->getOption('sort',$scriptProperties,'name');
$dir = $modx->getOption('dir',$scriptProperties,'ASC');

/* build query */
$c = $modx->newQuery('Review');
$c->sortby($sort,$dir);
$reviews = $modx->getCollection('Review',$c);

/* iterate */
$output = '';
foreach ($reviews as $review) {
    $reviewArray = $review->toArray();
    $output .= $rev->getChunk($tpl,$reviewArray);
}

return $output;
