<?php
/**
 * @package reviews
 * @subpackage lexicon
 */

$_lang['prop_reviews.ascending'] = 'Ascending';
$_lang['prop_reviews.descending'] = 'Descending';
$_lang['prop_reviews.dir_desc'] = 'The direction to sort by.';
$_lang['prop_reviews.sort_desc'] = 'The field to sort by.';
$_lang['prop_reviews.tpl_desc'] = 'The chunk for displaying each row.';
